// index.js
const AWS = require('aws-sdk');

// Configurações do S3
const s3 = new AWS.S3({
  signatureVersion: 'v4', // obrigatório para presigned URLs
});
const BUCKET_NAME = process.env.BUCKET_NAME;
const EXPIRATION = parseInt(process.env.EXPIRATION, 10) || 60; // segundos

/**
 * Lambda Handler
 * Recebe um JSON via POST: { "key": "nome-do-arquivo.ext" }
 * Retorna: { "url": "presigned_url" }
 */
exports.handler = async (event) => {
  console.log('Evento recebido:', JSON.stringify(event));

  try {
    if (!event.body) {
      throw new Error('Request body vazio.');
    }

    const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
    const { key } = body;

    if (!key || typeof key !== 'string' || key.trim() === '') {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Chave do arquivo inválida ou não informada.' }),
      };
    }

    const params = {
      Bucket: BUCKET_NAME,
      Key: key,
      Expires: EXPIRATION,
    };

    const url = await s3.getSignedUrlPromise('putObject', params);

    console.log(`Presigned URL gerada para ${key}: ${url}`);

    return {
      statusCode: 200,
      body: JSON.stringify({ url }),
      headers: {
        'Content-Type': 'application/json',
      },
    };

  } catch (err) {
    console.error('Erro ao gerar presigned URL:', err);

    return {
      statusCode: 500,
      body: JSON.stringify({
        error: 'Erro interno ao gerar a URL.',
        details: err.message,
      }),
      headers: {
        'Content-Type': 'application/json',
      },
    };
  }
};
